package com.example.BaitapJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaitapJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
